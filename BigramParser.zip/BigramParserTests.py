import unittest
import BigramParser as BigramParserClass

class TestMethods(unittest.TestCase):
    parser = BigramParserClass.BigramParser()

    def test_parse_empty_string_returns_empty_list(self):
        self.assertEqual([],self.parser.parse_bigrams(""))

    def test_parse_one_word_returns_empty_list(self):
        self.assertEqual([],self.parser.parse_bigrams("Oneword"))

    def test_parse_nonetype_returns_error(self):
        with self.assertRaises(TypeError):
            self.parser.parse_bigrams(None)

    def test_parse_cases_are_parsed_into_lower_case(self):
        self.assertEqual(['test test'],self.parser.parse_bigrams('TEST TeSt'))

    def test_parse_case_folding_handles_german(self):
        self.assertEqual(['strasse strasse'],self.parser.parse_bigrams('Straße Straße'))

    def test_parse_thousand_separator_not_parsed_as_boundary(self):
        self.assertEqual(['over 9,000'],self.parser.parse_bigrams("Over 9,000"))

    def test_parse_three_words(self):
        self.assertEqual(['word1 word2', 'word2 word3'], self.parser.parse_bigrams("word1 word2 word3"))
    
    def test_parse_four_words(self):
        self.assertEqual(['word1 word2', 'word2 word3', 'word3 word4'], self.parser.parse_bigrams("word1 word2 word3 word4"))
    
    def test_parse_assignment_string(self):
        compare=['and the', 'blue hare', 'brown fox', 'fox and', 'quick blue', 'quick brown', 'the quick', 'the quick']
        compare.sort()
        bigrams=self.parser.parse_bigrams("The quick brown fox and the quick blue hare.")
        self.assertEqual(compare, bigrams)

    def test_boundary_comma_not_treated_as_word_boundary_in_number(self):
        self.assertEqual(False, self.parser.is_boundary(",","9"))

    def test_boundary_comma_treated_as_word_boundary_in_text(self):
        self.assertEqual(True, self.parser.is_boundary(",","over"))

    def test_count_nonetype_returns_error(self):
        with self.assertRaises(TypeError):
            self.parser.count_bigrams(None)

    def test_count_empty_list_returns_error(self):
        with self.assertRaises(Exception):
            self.parser.count_bigrams([])

    def test_count_assignment_string(self):
        compare = {'and the': 1, 'blue hare': 1, 'brown fox': 1, 'fox and': 1, 'quick blue': 1, 'quick brown': 1, 'the quick': 2}
        bigrams =['and the', 'blue hare', 'brown fox', 'fox and', 'quick blue', 'quick brown', 'the quick', 'the quick']
        histogram = self.parser.count_bigrams(bigrams)
        self.assertEqual(compare,histogram)
# assumptions from the data presented;
# [ ] sanitize input

if __name__ == '__main__':
    unittest.main()
