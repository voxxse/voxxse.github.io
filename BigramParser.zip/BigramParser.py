#!/bin/python

from sys import argv

# assumptions
# We should handle Unicode without breaking, but we aren't doing true international support.
# Since we're encouraged to 'reinvent the wheel' on the bigram parser, we'll optimize for easy to
# read and testable logic. There are already methods that do the work.
# not reinventing the wheel on lowercasing a string. not sure if that was expected here.

class BigramParser:
    def __init__(self):
        self.word_boundaries = [" ", ":","-","_", ";", ",", ".", "[","]","/","\\","?","<",">","(",")","{","}","»","\n"]

    #determine, if, given the previous word, a glyph should be considered a word separator
    def is_boundary(self, glyph, word):
        if glyph in [",","."] and word.isnumeric():
            return False

        if glyph in self.word_boundaries:
            return True

    def parse_bigrams(self,input_string):
        if input_string is None:
            raise TypeError('Input must be a valid string.')

        bigrams=[]
        last_word=None
        current_word = ""

        # add a word boundary at the end to force a flush
        input_string = input_string + ' '

        for glyph in input_string.casefold():

            if not self.is_boundary(glyph, current_word):
                current_word += glyph

            elif current_word != "":

                if last_word is not None:
                    bigram = last_word + " " + current_word
                    bigrams.append(bigram)

                last_word=current_word
                current_word=""

        bigrams.sort()
        return bigrams

    def count_bigrams(self,bigrams):

        if not isinstance(bigrams, list):
            raise TypeError('Input must be a list.')

        if len(bigrams) == 0:
            raise Exception('Must not be an empty list.')

        bigrams.sort()
        histogram={}
        current_bigram = None
        count = 1

        for bigram in bigrams:

            if current_bigram == bigram:
                count += 1

            else:
                current_bigram = bigram
                count = 1

            histogram[bigram]=count

        return histogram

if __name__ == '__main__':

    if len(argv) == 1:
        print ("Usage: python BigramParser.py StringToParse")
        print ("Since no input was given, we'll use an example string for this run.")
        target = "This is the test string. The test string is for testing the test string."

    else:
        target = " ".join(argv[1:])
    
    bp = BigramParser()
    bigrams = bp.parse_bigrams (target)
    bigrams.sort()
    print(bp.count_bigrams(bigrams))
